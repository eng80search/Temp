$(function() {
    // Breakpoint Flag:
    var window_width = getWindowSize();
    var is_sp = (window_width < 1024);
    $(window).on('resize', function() {
        var window_width = getWindowSize();
        is_sp = (window_width < 1024);
    });
    function getWindowSize()
    {
        // return $(window).width();
        return window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
    }

    // Header Dropdown:
    $(document).on('mouseover', '.vpcx_header-opener', function() {
        if (!is_sp) {
            var $this = $(this);
            setTimeout(function() {
                $('.vpcx_header-toggle').hide();
                // $('.vpcx_header-toggle').each(function(i) {
                //   var parent_a = $this.parents().first();
                //   var parent_b = $(this).prev().parents().first();
                //   if (!parent_a.is(parent_b)) {
                //     // console.log(1);
                //     // $(this).slideUp(300);
                //     $(this).hide();
                //   }
                // });
                if ($this.next('.vpcx_header-toggle').length > 0) {
                    $this.next('.vpcx_header-toggle').slideDown(300, function() {
                        $this.removeClass('js-wait');
                    });
                }
            }, 200);
        }
    });

    // Header Dropout
    $(document).on('mouseover', function(e) {
        if (!is_sp) {
            // console.log(e.target);
            if (!$(e.target).closest('.vpcx_header-opener, .vpcx_header-toggle').length) {
                // $('.vpcx_header-toggle').removeClass('js-wait').slideUp(300);
                setTimeout(function() {
                    $('.vpcx_header-toggle').removeClass('js-wait').hide();
                }, 200);
            }
        }
    });

    // Hamburger menu:
    $(document).on('click', '#vpcx_header_sp_menu_opener', function() {
        if (!is_sp) {
            return false;
        }
        var $this = $(this);
        var target = $(this).attr('data-target');
        var active_class = 'active';
        var wait_class = 'js-vpcx_menu_wait';
        if (target !== undefined) {
            var $target = $(target);
            if ($this.hasClass(active_class)) {
                // Close:
                $this.removeClass(active_class);
                $target.removeClass(active_class);
                $('body').removeClass(wait_class);
            } else {
                // Open:
                $this.addClass(active_class);
                $target.addClass(active_class);
                $('body').addClass(wait_class);
            }
        }
        return false;
    });

    // SP Toggle:
    $(document).on('click', '.vpcx_header-opener, .vpcx_header-sp_opener', function() {
        var active_class = 'active';
        var toggle_speed = 100;

        var $this = $(this);
        var $target = $this.next('.vpcx_header-sp_toggle');
        if (is_sp) {
            if ($target !== undefined && $target.length > 0) {
                if ($this.hasClass(active_class)) {
                    $this.removeClass(active_class);
                    // $target.slideUp();
                    $target.hide();
                } else {
                    $this.addClass(active_class);
                    $target.slideDown(toggle_speed);
                }
            }
        }
        return false;
    });



    // ________________________________________________________ Footer
    // Hamburger menu:
    $(document).on('click', '#store_footer_sp_menu_opener', function() {
        if (!is_sp) {
            return false;
        }
        var $this = $(this);
        var target = $(this).attr('data-target');
        var active_class = 'active';
        var wait_class = 'js-store_menu_wait';
        if (target !== undefined) {
            var $target = $(target);
            if ($this.hasClass(active_class)) {
                // Close:
                $this.removeClass(active_class);
                $target.removeClass(active_class);
                $('body').removeClass(wait_class);
            } else {
                // Open:
                $this.addClass(active_class);
                $target.addClass(active_class);
                $('body').addClass(wait_class);
            }
        }
        return false;
    });

    // SP Toggle:
    $(document).on('click', '.store_footer-opener, .store_footer-sp_opener', function() {
        var active_class = 'active';
        var toggle_speed = 100;

        var $this = $(this);
        var $target = $this.next('.store_footer-sp_toggle');
        if (is_sp) {
            if ($target !== undefined && $target.length > 0) {
                if ($this.hasClass(active_class)) {
                    $this.removeClass(active_class);
                    // $target.slideUp();
                    $target.hide();
                } else {
                    $this.addClass(active_class);
                    $target.slideDown(toggle_speed);
                }
            }
        }
        return false;
    });
});
