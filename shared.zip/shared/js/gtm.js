
//カスタム変数（カスタムディメンション）設定GTM版
if(typeof ga_cstm != "undefined") {
 if(ga_cstm[0] == 1){ //trial
  dataLayer=[{'trial' : ga_cstm[2]}];
 }else if(ga_cstm[0] == 2) { //promo
  dataLayer=[{'promo' : ga_cstm[2]}];
 }else if(ga_cstm[0] == 3) { //store
  dataLayer=[{'store' : ga_cstm[1] + '|' + ga_cstm[2]}];
 }else if(ga_cstm[0] == 4) { //new
  dataLayer=[{'new' : ga_cstm[2]}];
 }else if(ga_cstm[0] == 5) { //member
  dataLayer=[{'member' : ga_cstm[2]}];
 }else if(ga_cstm[0] == 6) { //product
  dataLayer=[{'product' : ga_cstm[2]}];
 }
}

//GTM基本タグ
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0], j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src= '//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','GTM-MT2LLW');

//trackEvent関数GTM版
var trackEvent = function(category, action, label) {

 /**
  *以下、デバッグ用
  *不適切な値を発見した場合、三つの引数をそれぞれ上書きします。
  */
 var arg, args, i, msg, nullStringError, typeError, _i, _len;
 args = Array.prototype.slice.call(arguments);
 msg = [];

 if (args.length > 3) {
  msg.push('Too much args');
 } else if (args.length < 3) {
  msg.push('Need more args');
 }
 typeError = [];
 nullStringError = [];
 for (i = _i = 0, _len = args.length; _i < _len; i = ++_i) {
  arg = args[i];
  if (i < 3) {
   if (typeof arg !== 'string') {
    args[i] = typeof arg;
    typeError.push("[" + i + "]");
   } else {
    if (arg.length === 0) {
     args[i] = 'null';
     nullStringError.push("[" + i + "]");
    }
   }
  } else {
   args[i] = '...';
  }
 }
 if (typeError.length > 0) {
  msg.push('args' + typeError.join('') + " isn't String");
 }
 if (nullStringError.length > 0) {
  msg.push('args' + nullStringError.join('') + " needs more than ''");
 }

 if (msg.length > 0) {
  category = 'EventTrackingError';
  action = 'trackEvent';
  label = msg.join(',') + '/ @trackEvent(' + args.join(',') + ')';
 }
 /**
  *以上、デバッグ用
  */

 dataLayer.push({'eventCategory': category,'eventAction': action,'eventLabel': label});
};

