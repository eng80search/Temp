;(function($) {
	function LoadHeaderAndFooter(ele, options) {
		this.defaults = {
			root : $(ele),
			loaded : {
				'hdr' : undefined,
				'ftr' : undefined,
				'spm' : undefined
			},
			urls : {}
		};
		this.opts = $.extend(this.defaults, options);
		this.cnt = 0;
		this.init();
	};
	LoadHeaderAndFooter.prototype = {
		init : function() {
			// アキュビュー静的 基本セット
			if ($('body').hasClass('includeTypeA')) {
				this.opts.urls = {
					'hdr' : '/shared/include/headertype01.htm',
					'ftr' : '/shared/include/footertype01.htm',
					'spm' : '/shared/include/spmenu.htm'
				};
				// アキュビュー静的 【ヘッダー】ロゴのみ【フッター】リンク_blank
			} else if ($('body').hasClass('includeTypeB')) {
				this.opts.urls = {
					'hdr' : '/shared/include/headertype02.htm',
					'ftr' : '/shared/include/footertype02Blank.htm',
					'spm' : undefined
				};
				// アキュビュー静的 【ヘッダー】なし【フッター】基本ファイル
			} else if ($('body').hasClass('includeTypeC')) {
				this.opts.urls = {
					'hdr' : undefined,
					'ftr' : '/shared/include/myacuvuefooter.htm',
					'spm' : undefined
				};
				// アキュビュー静的 【ヘッダー】ロゴのみ【フッター】リンクなし
			} else if ($('body').hasClass('includeTypeD')) {
				this.opts.urls = {
					'hdr' : '/shared/include/headertype02.htm',
					'ftr' : '/shared/include/footertype03.htm',
					'spm' : undefined
				};
				// 取扱い店検索 印刷ページ用
			} else if ($('body').hasClass('includeTypeP01')) {
				this.opts.urls = {
					'hdr' : undefined,
					'hdr' : '/shared/include/headertype02.htm',
					'spm' : undefined
				};
			}
			this.loadCtrlr();
		},
		loadCtrlr : function() {
			var key;
			for (key in this.opts.loaded) {
				this.ajaxLoad(this.opts.urls[key], key)
			}
			//this.putHtml()
			//}
		},
		putHtml : function(key) {
			var root = this.opts.root, o = this.opts;
			if (root.find('#header').length <= 0 && key == 'hdr') {
				root.children().eq(0).before(o.loaded[key]);
			} else if (root.find('#header').length > 0 && key == 'hdr') {
				$('.js-navProduct').find('a').attr('href', 'javascript:;');
			}
			if (root.find('#footer').length <= 0 && key == 'ftr') {
				root.children().eq(root.children().length - 1).after(o.loaded[key]);
			};
			if (root.find('#footer').length > 0 && root.find('#footer02').length <= 0 && key == 'ftr') {
				var f2 = $($(o.loaded[key]).remove('#footer'));
				root.children().eq(root.children().length - 1).after(f2);
			};
			if (root.find('.spMenuA01').length <= 0 && root.find('.spMenuA02').length <= 0 && key == 'spm') {
				root.children().eq(root.children().length - 1).after(o.loaded[key]);
			};
			this.cnt++
			if (this.cnt == 3) {
				this.addUpdate();
				this.addCurrent();
				this.getUTCDateByServer();
				this.addPositionFixHeader();
				$('#wrap').dtsubnav();
				$('#nav').dtDropDwonMenu();
			};
			$('body').delegate('a[href^=#]:not(.popup-modal)', 'click.o', function() {
				var speed = 400, href = $(this).attr('href'), target = $(href == '#' || href == '' ? 'html' : href), fh = 0, fb = 0, h = 0;

				if (target.closest('[role="accordion-btn"]').length > 0) {
					$.data(target.closest('[role="accordion-btn"]').parent().get(0), 'accordion').openPanel(~~(target.closest('[role="accordion-btn"]').attr('data-index')));
				}
				if (target.closest('[role="accordion-panel"]').length > 0) {
					$.data(target.closest('[role="accordion-panel"]').parent().get(0), 'accordion').openPanel(~~(target.closest('[role="accordion-panel"]').attr('data-index')));
				}

				if ($('#header').length > 0 && $('#header').css('position') == 'fixed') {
					fh = $('#header').height();
				}

				if ($('#fixedBox').length > 0 && $('#fixedBox').css('position') == 'fixed') {
					fb = $('#fixedBox').height();
				}
				h = fh > fb ? fh : fb;
				if (target.length) {
					var position = target.offset().top - h;
					$('html, body').animate({
						scrollTop : position
					}, speed, 'swing');
				}
				return false;
			});

			if ( typeof location.href.split("#")[1] != 'undefined') {
				var target = $('#' + location.href.split("#")[1]), fh = 0, fb = 0, h = 0;
				if (target.length) {
					if ($('#header').length > 0 && $('#header').css('position') == 'fixed') {
						fh = $('#header').height();
					}

					if ($('#fixedBox').length > 0 && $('#fixedBox').css('position') == 'fixed') {
						fb = $('#fixedBox').height();
					}
					h = fh > fb ? fh : fb;

					var position = target.offset().top - h;
					if (target.length) {
						$('html,body').animate({
							scrollTop : position
						}, 0, 'swing');
						return false;
					}
				}
			}
		},
		addUpdate : function() {
			if ($('meta[name=date]').length > 0 && $('.lastUpdated').length > 0) {
				var date, month, year, ref, m;
				m = ($('meta[name=date]').attr('content')).match(/(\d+)\D+(\d+)\D+(\d+)/);
				if (m != null) {
					ref = m.slice(1, 4);
					year = ~~(ref[0]);
					month = ~~(ref[1]);
					date = ~~(ref[2]);
					$('.lastUpdated').text('最終更新日：' + year + '年' + month + '月' + date + '日');
				}
			}
		},
		addCurrent : function() {
			if (location.pathname != "/") {
				$('#nav a[href^="/' + location.pathname.split("/")[1] + '"]').closest('li').addClass('active');
			}
		},
		addCopyrightTerm : function(yy) {
			var y = yy, root = this.opts.root, o = this.opts;
			if (yy != null) {
				if (root.find('#footer02').length > 0 && $('.copyrightTerm').length > 0 && parseInt(yy.getFullYear(), 10) > 2000) {
					$('.copyrightTerm').text('1997-' + yy.getFullYear());
				}
			}
		},
		addPositionFixHeader : function() {
			$(window).bind('scroll.o', function() {
				var s = $(document).scrollTop() || $(window).scrollTop();
				if (s > 640) {
					$('.goTop').stop().animate({
						'opacity' : 1
					}, {
						'duration' : 450
					});
				} else {
					$('.goTop').stop().animate({
						'opacity' : 0
					}, {
						'duration' : 450
					});
				}
			});
			$('.goTop').css({
				'opacity' : '0'
			});
			var s = $(document).scrollTop() || $(window).scrollTop()
			if (s > 640) {
				$('.goTop').stop().animate({
					'opacity' : 1
				}, {
					'duration' : 450
				});
			} else {
				$('.goTop').stop().animate({
					'opacity' : 0
				}, {
					'duration' : 450
				});
			}
		},
		addGotoTop : function() {
			return true;
		},
		ajaxLoad : function(u, key) {
			var t = this;
			if ( typeof u !== 'undefined') {
				$.ajax({
					url : u,
					dataType : 'html',
					success : function(html) {
						t.opts.loaded[key] = html;
						t.putHtml(key);
					}
				});
			} else {
				t.opts.loaded[key] = '';
				t.putHtml(key);
			}
		},
		getUTCDateByServer : function() {
			/*
 　			* MODE:true  ->サーバータイム
  　		* MODE:false ->西暦固定入力
			*/
			var MODE = false,yyyy = '2014';
			if(MODE){
				var date = null, t = this, oHead = $.ajax({
					'type' : 'HEAD',
					'url' : '/'
				}).success(function() {
					date = new Date(oHead.getResponseHeader('Date'));
					t.addCopyrightTerm(date);
				}).error(function(){
					$('.copyrightTerm').text('1997-' + yyyy);
				});
			} else {
				this.setConstDate(yyyy)
			}
		},
		setConstDate : function(yyyy){
			$('.copyrightTerm').text('1997-' + yyyy);
		}
	};
	$(function() {
		window.lhaf = new LoadHeaderAndFooter($('#wrap'), {});
	});
})(jQuery);
(function($) {
	$.dtsubnavtab = function(ele, options) {
		this.defaults = {
			root : $(ele),
			is : $(ele).attr('id'),
			cache : 0,
			selected : 0,
			selectedClass : "",
			notSP : false
		};
		this.opts = $.extend(this.defaults, options);
		this.init();
	};
	$.extend($.dtsubnavtab.prototype, {
		init : function() {
			var owner = this;
			owner.setDefaultSelected();
			owner.setBtnEvent();
		},
		setDefaultSelected : function() {
			var owner = this, root = owner.opts.root, c = owner.opts.selectedClass;
			root.children('ul').children('li[role*="tab-btn"]').each(function(i) {
				if (i == owner.opts.selected) {
					$(this).addClass(c)
				} else {
					$(this).removeClass(c)
				};
				$(this).attr('data-index', i)
			});
			root.children('div[role*="tab-panel"]').each(function(i) {
				if (i != owner.opts.selected) {
					$(this).css({
						'display' : 'none'
					})
					owner.opts.cache = owner.opts.selected;
				} else {
					$(this).css({
						'display' : 'block'
					})
				};
				$(this).attr('data-index', i);
			});
		},
		setBtnEvent : function() {
			var owner = this, root = owner.opts.root, c = owner.opts.selectedClass;
			root.children('ul').children('li[role*="tab-btn"]').each(function(i) {
				$(this).children('a').bind('click.o', function(e) {
					if (!$(this).parent('li').hasClass(c)) {
						$(this).parent('li').addClass(c);
						root.children('ul').children('li[role*="tab-btn"]').eq(owner.opts.cache).removeClass(c);
						root.children('div[role*="tab-panel"]').eq(owner.opts.cache).css({
							'display' : 'none'
						});
						root.children('div[role*="tab-panel"]').eq(parseInt($(this).parent('li').attr('data-index'), 10)).css({
							'display' : 'block'
						});
						owner.opts.cache = parseInt($(this).parent('li').attr('data-index'), 10);
					}
					e.preventDefault();
					return false;
				})
			});
		}
	});
	$.fn.dtsubnavtab = function(options) {
		return this.each(function() {
			var obj = new $.dtsubnavtab(this, options);
			$.data(this, 'tab', obj);
		});
	};
})(jQuery);
;(function($) {
	$.dtsubnav = function(ele, options) {
		this.defaults = {
			root : $(ele),
			is : $(ele).attr('id'),
			cacheNav : undefined,
			cacheSer : undefined
		};
		this.resizeTimer = undefined;
		this.opts = $.extend(this.defaults, options);
		this.init()
	};
	$.extend($.dtsubnav.prototype, {
		init : function() {
			var owner = this, search = '', navStr = '';
			/*
			*
			*/
			//search += '<div class="spMenuBG02"></div>';
			search = $('.spMenuA02,.spMenuBG02');
			search.css({
				'height' : 0,
				'overflow' : 'hidden'
			})
			//search.remove()
			/*
			*
			*/
			//navStr += '<div class="spMenuBG" style="height: 768px"></div>';
			navStr = $('.spMenuA01,.spMenuBG');
			navStr.remove()

			/*
			 *
			 */
			owner.search = search;
			owner.navStr = navStr;
			owner.resizeCloser();
			owner.setBtnEvent();
		},
		resizeCloser : function() {
			var owner = this;
			$(window).resize(function() {
				owner.debouncer(owner.autoClose, 'resizeTimer', 100, owner);
			})
		},
		autoClose : function() {
			if ($(window).width() >= 768) {
				if ($('a[role="js-search-close"]').length > 0) {
					$('a[role="js-search-close"]').trigger('click');
				}
				if ($('a[role="js-nav-close"]').length > 0) {
					$('a[role="js-nav-close"]').trigger('click');
				}
			}
		},
		debouncer : function(func, timer, timeout, scope) {
			timeout = timeout || 200;
			var scope = typeof scope === 'undefined' ? this : scope, args = arguments;
			if ( typeof scope[timer] != 'number') {
				clearTimeout(scope[timer]);
				scope[timer] = setTimeout(function() {
					clearTimeout(scope[timer]);
					func.apply(scope, Array.prototype.slice.call(args));
					scope[timer] = undefined;
				}, timeout);
			}
		},
		setDefaultSelected : function() {
			var owner = this, root = owner.opts.root;
			root.children('ul').children('li[role*="tab-btn"]').each(function(i) {
				if (i == owner.opts.selected) {
					$(this).addClass(owner.opts.selectedClass);
				}
				$(this).attr('data-index', i);
			});
			root.children('div[role*="tab-panel"]').each(function(i) {
				if (i !== owner.opts.selected) {
					$(this).css({
						'display' : 'none'
					});
					owner.opts.cache = owner.opts.selected;
				}
				$(this).attr('data-index', i);
			});
		},
		setBtnEvent : function() {
			var owner = this, root = owner.opts.root;
			$('#js-menu').bind('click.o', function() {
				var h = (window.innerWidth > window.innerHeight) ? window.innerWidth : window.innerHeight, stid;
				h = h > 768 ? h : 768;
				stid = setTimeout(function() {
					$('#js-subNavTab').dtsubnavtab({
						selectedClass : 'active'
					});
					root.css({
						'overflow' : 'hidden',
						'display' : 'block',
						'height' : h + 'px'
					});
					$('.spMenuBG').css({
						'display' : 'block',
						'height' : h + 'px'
					});
					$('.spMenuA01').css({
						'display' : 'block',
						'height' : h + 'px',
						'-webkit-transform' : 'translateZ(0)'
					});

				}, 1);
				if ($('.spMenuBG').length <= 0 && $('.spMenuA01').length <= 0) {
					owner.opts.cacheNav = root.children().eq(0).before(owner.navStr);
				}
				//if ($('body').attr('id') === 'top') {
				$('.spMenuBG,.spMenuA01').css({
					'display' : 'block'
				});
				//}
				return false;
			})
			$(document).delegate('#js-search', 'click.o', function() {
				//owner.opts.cacheSer = root.children().eq(0).before(owner.search)
				//if ($('body').attr('id') === 'top') {
				$('.spMenuBG02,.spMenuA02').css({
					'display' : 'block'
				})
				$('.spMenuA02').css({
					'height' : 'auto',
					'overflow' : 'visible'
				})
				$('.spMenuBG02').css({
					'height' : '124px'
				})
				//}
				$('#contentsBody').css({
					'margin-top' : '54px'
				});
				return false;
			})
			$(document).delegate('a[role="js-search-close"],a[role="js-nav-close"]', 'click.o', function() {
				root.css({
					'overflow' : '',
					'display' : '',
					'height' : ''
				});
				if ($('.spMenuA01').length > 0)
					$('.spMenuA01').remove();
				if ($('.spMenuA02').length > 0)
					//$('.spMenuA02').remove();
					$('.spMenuA02').css({
						'height' : '0',
						'overflow' : 'hidden'
					})
				if ($('.spMenuBG').length > 0)
					$('.spMenuBG').remove();
				if ($('.spMenuBG02').length > 0) {
					$('.spMenuBG02').css({
						'height' : '0',
						'overflow' : 'hidden'
					})

				}
				//root.removeAttr('style');
				$('#contentsBody').css({
					'margin-top' : ''
				})
				return false;
			})
		}
	});
	$.fn.dtsubnav = function(options) {
		return this.each(function() {
			new $.dtsubnav(this, options);
		});
	};

})(jQuery);

;(function($) {
	$.dtDropDwonMenu = function(ele, options) {
		this.defaults = {
			root : $(ele),
			is : $(ele).attr('id'),
			cacheNav : undefined,
			cacheSer : undefined,
			isShow : false
		};
		this.resizeTimer = undefined;
		this.opts = $.extend(this.defaults, options);
		this.init()
	};
	$.extend($.dtDropDwonMenu.prototype, {
		init : function() {
			var owner = this, dropDownMenu = '';
			/*
			 *
			 */
			dropDownMenu = $('.productNavArea');
			/*
			 *
			 */
			owner.ddm = dropDownMenu;
			owner.resizeCloser();
			owner.changeEventByWindowResize();
		},
		resizeCloser : function() {
			var owner = this;
			$(window).resize(function() {
				owner.debouncer(owner.changeEventByWindowResize, 'resizeTimer', 100, owner)
			})
		},
		changeEventByWindowResize : function() {
			var owner = this, w = $(window).width();
			owner.hideDropDownMenu();
			if (w < 767) {
				owner.setBtnEventForSP();
			} else if (w >= 768 && w < 1024) {
				owner.setBtnEventForTB();
			} else {
				owner.setBtnEventForPC();
			}
		},
		debouncer : function(func, timer, timeout, scope) {
			timeout = timeout || 200;
			var scope = typeof scope === 'undefined' ? this : scope, args = arguments;
			if ( typeof scope[timer] != 'number') {
				clearTimeout(scope[timer]);
				scope[timer] = setTimeout(function() {
					clearTimeout(scope[timer]);
					func.apply(scope, Array.prototype.slice.call(args));
					scope[timer] = undefined;
				}, timeout);
			}
		},
		setDefaultSelected : function() {
			var owner = this, root = owner.opts.root;
			root.children('ul').children('li[role*="tab-btn"]').each(function(i) {
				if (i == owner.opts.selected) {
					$(this).addClass(owner.opts.selectedClass);
				}
				$(this).attr('data-index', i);
			});
			root.children('div[role*="tab-panel"]').each(function(i) {
				if (i != owner.opts.selected) {
					$(this).css({
						'display' : 'none'
					})
					owner.opts.cache = owner.opts.selected;
				};
				$(this).attr('data-index', i);
			});
		},
		setBtnEventForSP : function() {
			var owner = this, root = owner.opts.root;
			root.find('li').eq(0).unbind('click.o mouseover.o');
			$('body').unbind('mousemove.o');
			$('#productNavBG').unbind('click.o');
			root.parent().undelegate('#js-ddclose', 'click.o');
		},
		setBtnEventForTB : function() {
			/*var owner = this, root = owner.opts.root;
			 root.find('li').eq(0).unbind('mouseover.o').bind('click.o', function(e) {
			 owner.showDropDownMenu();
			 e.preventDefault();
			 return false;
			 })
			 $('#productNavBG').unbind('click.o').bind('click.o', function() {
			 owner.hideDropDownMenu();
			 return false;
			 })
			 $('body').unbind('click.o');
			 root.parent().undelegate('#js-ddclose', 'click.o').delegate('#js-ddclose', 'click.o', function() {
			 owner.hideDropDownMenu();
			 return false;
			 })*/
			var owner = this, root = owner.opts.root;
			$('.js-navProduct').find('a').attr('href', '/product/');
			root.find('li').eq(0).unbind('click.o').bind('click.o', function() {
				if (!owner.isShow) {
					owner.showDropDownMenu();
					return false;
				} else {
					return true
				}
			})
			$('body').bind('click.o', function(e) {
				if ($(e.target).closest('.productNavArea').length > 0 || $(e.target).closest('.js-navProduct').length > 0) {
				} else {
					owner.hideDropDownMenu();
				}
				//return false;
			});
			$('#productNavBG').unbind('click.o');
			root.parent().undelegate('#js-ddclose', 'click.o').delegate('#js-ddclose', 'click.o', function() {
				owner.hideDropDownMenu();
				return false;
			})
		},
		setBtnEventForPC : function() {
			var owner = this, root = owner.opts.root;
			$('.js-navProduct').find('a').attr('href', '/product/');
			root.find('li').eq(0).unbind('click.o').bind('click.o', function() {
				if (!owner.isShow) {
					owner.showDropDownMenu();
					return false;
				} else {
					return true
				}
			})
			$('body').bind('click.o', function(e) {
				if ($(e.target).closest('.productNavArea').length > 0 || $(e.target).closest('.js-navProduct').length > 0) {
				} else {
					owner.hideDropDownMenu();
				}
				//return false;
			});
			$('#productNavBG').unbind('click.o');
			root.parent().undelegate('#js-ddclose', 'click.o').delegate('#js-ddclose', 'click.o', function() {
				owner.hideDropDownMenu();
				return false;
			})
		},
		showDropDownMenu : function() {
			var owner = this, root = owner.opts.root, h;
			if ($('#productNavBG').length <= 0 && $('.productNavArea').length <= 0) {
				var sid = setTimeout(function() {
					$('#productNav').stop().animate({
						'height' : h + 'px'
					}, {
						'duration' : 300,
						'easing' : 'easeOutExpo'
					});

					//画面の高さを取得してスクロール
					var wH = $(window).height();
					$('#top div#productNav').css('max-height', wH - 170 + 'px');
					$('#top div#productNav .productBoxA02').css('max-height', wH - 240 + 'px');
					$('#lower div#productNav').css('max-height', wH - 130 + 'px');
					$('#lower div#productNav .productBoxA02').css('max-height', wH - 200 + 'px');

				}, 0)
				if ($('#productNavBG').length <= 0) {
					root.parent().append('<div id="productNavBG"></div>')
				}
				root.parent().append(owner.ddm);
				$('.productNavArea').css({
					'display' : 'block'
				})
				h = $('#productNav').removeAttr('style').height();
				$('#productNav').css({
					'height' : '0',
					'overflow' : 'hidden'
				})
				owner.isShow = true;
			}
		},
		hideDropDownMenu : function() {
			var owner = this;
			if ($('#productNavBG').length > 0) {
				$('#productNavBG').remove();
			}
			if ($('.productNavArea').length > 0) {
				$('.productNavArea').remove();
			}
			owner.isShow = false;
		}
	});
	$.fn.dtDropDwonMenu = function(options) {
		return this.each(function() {
			new $.dtDropDwonMenu(this, options);
		});
	};
	/*
	* jQuery Easing v1.3 - http://gsgd.co.uk/sandbox/jquery/easing/
	*
	* Uses the built in easing capabilities added In jQuery 1.1
	* to offer multiple easing options
	*
	* TERMS OF USE - jQuery Easing
	*
	* Open source under the BSD License.
	*
	* Copyright c 2008 George McGinley Smith
	* All rights reserved.
	*
	* Redistribution and use in source and binary forms, with or without modification,
	* are permitted provided that the following conditions are met:
	*
	* Redistributions of source code must retain the above copyright notice, this list of
	* conditions and the following disclaimer.
	* Redistributions in binary form must reproduce the above copyright notice, this list
	* of conditions and the following disclaimer in the documentation and/or other materials
	* provided with the distribution.
	*
	* Neither the name of the author nor the names of contributors may be used to endorse
	* or promote products derived from this software without specific prior written permission.
	*
	* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
	* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
	* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
	*  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
	*  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
	*  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
	* AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
	*  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
	* OF THE POSSIBILITY OF SUCH DAMAGE.
	*
	*/

	// t: current time, b: begInnIng value, c: change In value, d: duration
	jQuery.easing['jswing'] = jQuery.easing['swing'];
	jQuery.extend(jQuery.easing, {
		def : 'easeOutQuad',
		easeOutExpo : function(x, t, b, c, d) {
			return (t == d) ? b + c : c * (-Math.pow(2, -10 * t / d) + 1) + b;
		}
	});

	/*
	 *
	 * TERMS OF USE - EASING EQUATIONS
	 *
	 * Open source under the BSD License.
	 *
	 * Copyright c 2001 Robert Penner
	 * All rights reserved.
	 *
	 * Redistribution and use in source and binary forms, with or without modification,
	 * are permitted provided that the following conditions are met:
	 *
	 * Redistributions of source code must retain the above copyright notice, this list of
	 * conditions and the following disclaimer.
	 * Redistributions in binary form must reproduce the above copyright notice, this list
	 * of conditions and the following disclaimer in the documentation and/or other materials
	 * provided with the distribution.
	 *
	 * Neither the name of the author nor the names of contributors may be used to endorse
	 * or promote products derived from this software without specific prior written permission.
	 *
	 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
	 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
	 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
	 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
	 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
	 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
	 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
	 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
	 * OF THE POSSIBILITY OF SUCH DAMAGE.
	 *
	 */
})(jQuery);

