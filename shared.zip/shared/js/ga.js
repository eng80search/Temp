var _gaq = _gaq || [];
var pluginUrl = '//www.google-analytics.com/plugins/ga/inpage_linkid.js';
_gaq.push(['_require', 'inpage_linkid', pluginUrl]);
_gaq.push(['_setAccount', 'UA-27042241-1']);
_gaq.push(['_addIgnoredRef', 'survey.acuvue.jnj.co.jp']);
_gaq.push(['_addIgnoredRef', '1dayacuvuedefine.jp']);
_gaq.push(['_addIgnoredRef', 'hitomi121.1dayacuvuedefine.jp']);
_gaq.push(['_setDomainName', 'acuvue.jnj.co.jp']);
_gaq.push(['_setAllowLinker', true]);
if(typeof ga_cstm != "undefined") {
	_gaq.push(['_setCustomVar', ga_cstm[0], ga_cstm[1], ga_cstm[2], ga_cstm[3]]);
}
_gaq.push(['_trackPageview']);

(function() {
	var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();

function trackEvent(cat,act,id){_gaq.push(['_trackEvent', cat,act,id]);}