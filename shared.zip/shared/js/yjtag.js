( function() {
		var tagjs = document.createElement("script");
		var s = document.getElementsByTagName("script")[0];
		tagjs.async = true;
		tagjs.src = "//s.yjtag.jp/tag.js#site=T3kUB82";
		s.parentNode.insertBefore(tagjs, s);
	}());
