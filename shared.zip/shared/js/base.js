(function($) {
	$(function() {

		var ua = window.navigator.userAgent.toLowerCase();
		var appVersion = window.navigator.appVersion.toLowerCase();
		var clrtp = true;
		if (ua.indexOf('msie') != -1) {
			if (appVersion.indexOf('msie 6.') > 0 || appVersion.indexOf("msie 7.") > 0 || appVersion.indexOf("msie 8.") > 0) {
				clrtp = false;
			}
		};
		//フォーム画像プリロード
		jQuery.preloadImages = function(){
			for(var i = 0; i<arguments.length; i++){
				jQuery("<img>").attr("src", arguments[i]);
			}
		};
		$.preloadImages("/shared/img/cmn_check_001.gif","/shared/img/cmn_check_001disabled.png","/shared/img/cmn_check_001off.gif","/shared/img/cmn_check_001off.png","/shared/img/cmn_check_002off.png","/shared/img/cmn_check_002on.png","/shared/img/cmn_radio_001disabled.png","/shared/img/cmn_radio_001off.png","/shared/img/cmn_radio_001on.png");

		//iPad
		$("label").click(function() {
		});

		if ($(".checkbox").is(":checked")) {
			$(".checkbox:checked").next("label").addClass("checkboxON");
		}

		$(".checkbox").change(function() {
			if ($(this).is(":checked")) {
				$(this).next("label").addClass("checkboxON");
			} else {
				$(this).next("label").removeClass("checkboxON");
			}
		});

		$(".radio").change(function() {
			if ($(this).is(":checked")) {
				$(".radio:not(:checked)").next("label").removeClass("radioON");
				$(this).next("label").addClass("radioON");
			}
		});

		$('#wrap').delegate('input:text,input:password', 'focus.o', function(e) {
			$(this).prev('.placeholder').hide();
			$(this).addClass("textFocus");
			$(this).css('color', '#1f1f1f');
			e.stopPropagation();
		}).delegate('input:text,input:password', 'blur.o', function(e) {
			if ($(this).val() == '') {
				$(this).prev('.placeholder').show();
				$(this).removeClass("textFocus");
				$(this).css('color', '#999999');
			} else {
				$(this).prev('.placeholder').hide();
			}
			e.stopPropagation();
			return false;
		});
		$('#wrap').delegate('.placeholder', 'click.o', function(e) {
			$(this).next('input').focus();
			e.stopPropagation();
			return false;
		});
		$('#wrap').delegate('a[role="remove-text"]', 'click.o', function() {
			$(this).prev().val('').focus()
		});
		$('#wrap').delegate('a[role="remove-text-subnav"]', 'click.o', function() {
			$(this).parent().parent().find('input').val('').focus()
		});

		$('input:text,input:password').trigger('blur')

		// detailsBox
		$('.detailsBoxB01').not(".linkAreaNone,.indexMontylyInfoBox01").click(function() {
			window.location = $(this).find('a').attr('href');
			return false;
		});

	});
})(jQuery);

function print_new() {
	window.print();
}

;(function($) {
	$.fn.tile = function(columns) {
		var tiles, max, c, h, last = this.length - 1, s;
		if (!columns)
			columns = this.length;
		this.each(function() {
			s = this.style;
			if (s.removeProperty)
				s.removeProperty("height");
			if (s.removeAttribute)
				s.removeAttribute("height");
		});
		return this.each(function(i) {
			c = i % columns;
			if (c == 0)
				tiles = [];
			tiles[c] = $(this);
			h = tiles[c].height();
			if (c == 0 || h > max)
				max = h;
			if (i == last || c == columns - 1)
				$.each(tiles, function() {
					this.height(max);
				});
		});
	};

})(jQuery);
$(function() {
	$('.checkBoxA02 label').tile(2);

	$("#RblJobTypeCd input.radio").change(function() {
		if ($(this).val() === "99") {
			$("#scsk").slideDown();
			$("#TxtJobText").removeAttr("disabled");
			$("#TextBoxJob").removeAttr("disabled");
		} else {
			$("#scsk").slideUp();
			$("#TxtJobText").attr("disabled", "disabled");
			$("#TextBoxJob").attr("disabled", "disabled");
		}
	});

});


// 画像幅でキャプションを表示したい場合に使用する
$(window).bind('load',function(){
	$('.captionImg01').each(function(){
		pw = $(this).prev('img').width() + 'px';
		$(this).parent().css('width',pw);
	});
});

function popuplink(url) {

	//if (!window.opener || window.opener.closed) {
		window.open(url, '_blank', 'menubar=yes,toolbar=yes,location=yes,resizable=yes,scrollbars=yes');
	//} else {
	//	window.opener.location.href = url;
	//	if (navigator.userAgent.indexOf("Safari") != -1) {
	//		window.blur();
	//	}
	//	window.opener.focus();
	//}
}

//ブラウザ判別用JS
var _ua = (function(){
 return {
  ltIE6:typeof window.addEventListener == "undefined" && typeof document.documentElement.style.maxHeight == "undefined",
  ltIE7:typeof window.addEventListener == "undefined" && typeof document.querySelectorAll == "undefined",
  ltIE8:typeof window.addEventListener == "undefined" && typeof document.getElementsByClassName == "undefined",
  ltIE9:document.uniqueID && typeof window.matchMedia == "undefined",
  gtIE10:document.uniqueID && window.matchMedia,
  Trident:document.uniqueID,
  Gecko:'MozAppearance' in document.documentElement.style,
  Presto:window.opera,
  Blink:window.chrome,
  Webkit:typeof window.chrome == "undefined" && 'WebkitAppearance' in document.documentElement.style,
  Touch:typeof document.ontouchstart != "undefined",
  Mobile:typeof window.orientation != "undefined",
  ltAd4_4:typeof window.orientation != "undefined" && typeof(EventSource) == "undefined",
  Pointer:window.navigator.pointerEnabled,
  MSPoniter:window.navigator.msPointerEnabled
 }
})();

//SPで電話番号にリンク
$(function(){
    var ua = navigator.userAgent;
    if(ua.indexOf('iPhone') > 0 || ua.indexOf('Android') > 0){
      window.setTelLink = function(span) {
        var str = $(span).text();
        $(span).html($('<a>').attr('href', 'tel:' + str.replace(/-/g, '')).append(str + '</a>'));
      };
      $('.telLink').each(function(){
        setTelLink(this);
      });
    }
});

//iPhone・iOS向けCSSの読み込み
(function(){
    var _UA = navigator.userAgent;
    if (_UA.indexOf('iPhone') > -1 || _UA.indexOf('iPad') > -1) {
        var $link = $("<link>", {href:"/shared/css/iOS.css",rel:"stylesheet",type:"text/css"});
		$("head").append($link);
    }
})();



	var gssintid=setInterval(function(){
		  if($('.gsc-input input:first-child').length>0){
			  $(".gsc-input input:first-child").attr('placeholder','サイト内検索');
			  clearInterval(gssintid)
			}
	},33)


//MAフッターアコーディオン
$(function() {
    // Breakpoint Flag:
    var window_width = getWindowSize();
    var is_sp = (window_width < 1024);
    $(window).on('resize', function() {
        var window_width = getWindowSize();
        is_sp = (window_width < 1024);
    });
    function getWindowSize()
    {
        // return $(window).width();
        return window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
    }


    // ________________________________________________________ Footer
    var active_class = 'active';
    $(document).on('click', '.vpcx_footer-opener', function() {
        var toggle_speed = 0;

        if (is_sp) {
            var $this = $(this);
            var target = $(this).attr('data-target');
            if (target !== undefined) {
                var $target = $(target);
                if (!$target.length) {
                    return false;
                }

                if ($this.hasClass(active_class)) {
                    $this.removeClass(active_class);
                    // $target.slideUp();
                    $target.hide();
                } else {
                    $this.addClass(active_class);
                    $target.slideDown(toggle_speed);
                }
            }
        }
        return false;
    });
    $(window).on('resize', function() {
        if (!is_sp) {
            $('.vpcx_footer-opener').removeClass(active_class);
            $('.vpcx_footer-accordion').attr({
                style: ''
            });
        }
    });
});