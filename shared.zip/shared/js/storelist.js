;(function($) {
	function StoreList() {
		this.pagerCount = 15;
		this.currentPage = 1;
		this.maxPage = 0;
		this.w = undefined;
		this.heightCorrection = [];
		this.init();
	};
	StoreList.prototype = {
		init : function() {
			this.rebuildElement();
			this.setHoverOption();
			this.resizeCloser();
			this.changeEventByWindowResize();
			this.attachEvent();
			this.showAmount();
		},
		attachEvent : function() {
			var t = this, i, l;
			$('*[role=read-more]').find('a').bind('click.o', function() {
				if (t.currentPage < $('.read-more-pgr').length) {
					$('.read-more-pgr').eq(t.currentPage).stop().animate({
						'height' : t.heightCorrection[t.currentPage]
					}, {
						'duration' : 450,
						'easing' : 'easeOutExpo',
						'complete' : function() {
							t.currentPage++;
							t.showAmount();
						}
					});
				};

			})
		},
		hideMoreButton : function() {
			$('*[role=read-more]').css({
				'display' : 'none'
			})
		},
		rebuildElement : function() {
			var str = '', i, l, c = [], d = [], s = this.pagerCount;
			this.maxPage = $('div[role=read-more-panel] > div').length;
			$('div[role=read-more-panel] > div').each(function(i) {
				d[Math.floor(i / s)] = typeof d[Math.floor(i / s)] == 'undefined' ? $(this).wrap('<div></div>').parent().html() : d[Math.floor(i / s)] + $(this).wrap('<div></div>').parent().html();
			})
			$('div[role=read-more-panel]').children().remove();
			for ( i = 0, l = d.length; i < l; i++) {
				str += '<div class="read-more-pgr">' + d[i] + '</div>'
			}
			$('div[role=read-more-panel]').html(str);
		},
		setHoverOption : function() {
			$('div[role=read-more-panel] > .read-more-pgr > div,ul[role=read-more-panel] > .read-more-pgr > li').each(function() {
				if ($(this).hasClass('selected')) {
					$(this).removeClass('active')
				}
				$(this).bind('mouseover.o', function() {
					if (!$(this).hasClass('selected')) {
						$(this).addClass('active')
					}
				}).bind('mouseout.o', function() {
					if (!$(this).hasClass('selected')) {
						$(this).removeClass('active')
					}
				})
			})
			$('.read-more-pgr').removeAttr('style')
		},
		resetHoverOptionTB : function() {
			var t = this, i, l;
			$('div[role=read-more-panel] > .read-more-pgr > div,ul[role=read-more-panel] > .read-more-pgr > li').each(function() {
				if ($(this).hasClass('selected')) {
					$(this).addClass('active')
				};
				$(this).unbind('mouseover.o mouseout.o')
			});
			$('.read-more-pgr').removeAttr('style')
		},
		showAmount : function() {
			var t = this, i, l;
			if (t.currentPage >= $('.read-more-pgr').length) {
				t.hideMoreButton();
			}
			$('*[role=read-more-all]').text(t.maxPage);
			$('*[role=read-more-current]').text((t.pagerCount * t.currentPage + 1) + '～' + ((t.pagerCount * (t.currentPage + 1)) <= t.maxPage ? t.pagerCount * (t.currentPage + 1) : t.maxPage))
		},
		resetHoverOptionSP : function() {
			var t = this, i, l;
			$('div[role=read-more-panel] > .read-more-pgr > div,ul[role=read-more-panel] > .read-more-pgr > li').each(function() {
				if ($(this).hasClass('selected')) {
					$(this).addClass('active')
				};
				$(this).unbind('mouseover.o mouseout.o')
			});
			$('.read-more-pgr').each(function(i) {
				t.heightCorrection[i] = $(this).height();
				if (i < t.currentPage) {
					$('.read-more-pgr').removeAttr('style')
				} else {
					$(this).css({
						'height' : 0,
						'overflow' : 'hidden'
					});
				}
			});
		},
		resizeCloser : function() {
			var owner = this;
			$(window).resize(function() {
				if (owner.w != $(window).width()) {
					owner.debouncer(owner.changeEventByWindowResize, 'resizeTimer', 300, owner);

					owner.w = $(window).width()
				}

			});
		},
		changeEventByWindowResize : function() {
			var owner = this, w = $(window).width(), i, l;
			if (w < 768) {
				this.resetHoverOptionSP()
			} else if (w >= 768 && w < 1024) {
				this.resetHoverOptionTB()
			} else {
				this.setHoverOption()
			}
		},
		debouncer : function(func, timer, timeout, scope) {
			timeout = timeout || 200;
			var scope = typeof scope === 'undefined' ? this : scope, args = arguments;
			if ( typeof scope[timer] != 'number') {
				clearTimeout(scope[timer]);
				scope[timer] = setTimeout(function() {
					clearTimeout(scope[timer]);
					func.apply(scope, Array.prototype.slice.call(args));
					scope[timer] = undefined;
				}, timeout);
			}
		}
	};
	$(function() {
		window.strelst = new StoreList();
	});
	/*
	* jQuery Easing v1.3 - http://gsgd.co.uk/sandbox/jquery/easing/
	*
	* Uses the built in easing capabilities added In jQuery 1.1
	* to offer multiple easing options
	*
	* TERMS OF USE - jQuery Easing
	*
	* Open source under the BSD License.
	*
	* Copyright © 2008 George McGinley Smith
	* All rights reserved.
	*
	* Redistribution and use in source and binary forms, with or without modification,
	* are permitted provided that the following conditions are met:
	*
	* Redistributions of source code must retain the above copyright notice, this list of
	* conditions and the following disclaimer.
	* Redistributions in binary form must reproduce the above copyright notice, this list
	* of conditions and the following disclaimer in the documentation and/or other materials
	* provided with the distribution.
	*
	* Neither the name of the author nor the names of contributors may be used to endorse
	* or promote products derived from this software without specific prior written permission.
	*
	* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
	* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
	* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
	*  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
	*  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
	*  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
	* AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
	*  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
	* OF THE POSSIBILITY OF SUCH DAMAGE.
	*
	*/

	// t: current time, b: begInnIng value, c: change In value, d: duration
	jQuery.easing['jswing'] = jQuery.easing['swing'];

	jQuery.extend(jQuery.easing, {
		def : 'easeOutQuad',

		easeOutExpo : function(x, t, b, c, d) {
			return (t == d) ? b + c : c * (-Math.pow(2, -10 * t / d) + 1) + b;
		}
	});

	/*
	 *
	 * TERMS OF USE - EASING EQUATIONS
	 *
	 * Open source under the BSD License.
	 *
	 * Copyright © 2001 Robert Penner
	 * All rights reserved.
	 *
	 * Redistribution and use in source and binary forms, with or without modification,
	 * are permitted provided that the following conditions are met:
	 *
	 * Redistributions of source code must retain the above copyright notice, this list of
	 * conditions and the following disclaimer.
	 * Redistributions in binary form must reproduce the above copyright notice, this list
	 * of conditions and the following disclaimer in the documentation and/or other materials
	 * provided with the distribution.
	 *
	 * Neither the name of the author nor the names of contributors may be used to endorse
	 * or promote products derived from this software without specific prior written permission.
	 *
	 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
	 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
	 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
	 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
	 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
	 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
	 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
	 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
	 * OF THE POSSIBILITY OF SUCH DAMAGE.
	 *
	 */
})(jQuery);
