;(function($) {
	$.dttab = function(ele, options) {
		this.defaults = {
			root :$(ele),
			is :$(ele).attr('id'),
			cache :0,
			selected :0,
			selectedClass :"",
			pauseFlg :false
		};
		this.eventAttached = false;
		this.opts = $.extend(this.defaults, options);
		this.init();
	};
	$.extend($.dttab.prototype, {
		init :function() {
			var owner = this;
			owner.setDefaultSelected();
			owner.setBtnEvent();
		},
		setDefaultSelected :function() {
			var owner = this, root = owner.opts.root, c = owner.opts.selectedClass;
			root.children('ul').children('li[role*="tab-btn"]').each(function(i) {
				if (i == owner.opts.selected) {
					$(this).addClass(c)
				};
				$(this).attr('data-index', i)
			});
			root.children('div[role*="tab-panel"]').each(function(i) {
				if (i != owner.opts.selected) {
					$(this).css({
						'display' :'none'
					})
					owner.opts.cache = owner.opts.selected;
				} else {
					$(this).css({
						'display' :'block'
					})
				};
				$(this).attr('data-index', i);
			});
		},
		setBtnEvent :function() {
			var owner = this, root = owner.opts.root, c = owner.opts.selectedClass;
			if (!owner.eventAttached) {
				owner.eventAttached = true;
				root.children('ul').children('li[role*="tab-btn"]').each(function(i) {
					$(this).children('a').bind('click.o', function(e) {
						if (!$(this).parent('li').hasClass(c)) {
							$(this).parent('li').addClass(c);
							root.children('ul').children('li[role*="tab-btn"]').eq(owner.opts.cache).removeClass(c);
							root.children('div[role*="tab-panel"]').eq(owner.opts.cache).css({
								'display' :'none'
							});
							root.children('div[role*="tab-panel"]').eq(parseInt($(this).parent('li').attr('data-index'), 10)).css({
								'display' :'block'
							});
							owner.opts.cache = parseInt($(this).parent('li').attr('data-index'), 10);
						}
						e.preventDefault();
						return false;
					})
					$(this).children('a').css({
						'cursor' :'pointer'
					})
				});
			}
		},
		destroy :function() {
		},
		pause :function() {
			this.opts.pauseFlg = true;
			this.eventAttached = false;
			var owner = this, root = owner.opts.root, c = owner.opts.selectedClass;
			root.children('ul').children('li[role*="tab-btn"]').each(function() {
				$(this).children('a').unbind('click');
				$(this).children('a').css({
					'cursor' :'default'
				})
			});
		},
		restart :function() {
			this.opts.pauseFlg = false;
			if (!this.eventAttached) {
				this.setBtnEvent();
			}
		},
		openAllPanel :function() {
		}
	});
	$.fn.dttab = function(options) {
		return this.each(function() {
			var obj = new $.dttab(this, options);
			$.data(this, 'tab', obj);
		});
	};
})(jQuery);
