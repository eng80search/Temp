;(function($) {
	function NarrowSearchOptionView(ele, options) {
		this.defaults = {
			root : $(ele),
			loaded : [],
			urls : []
		};

		/*
		 *
		 */
		this.sortWrapper = undefined;
		this.sortAddressWrapper = [];
		this.sortSubOptWrapper = [];
		this.sortAddressTabWrapper = undefined;
		this.w = undefined;
		this.m = undefined;
		/*
		 *
		 */
		this.opts = $.extend(this.defaults, options);
		this.init();
	}


	NarrowSearchOptionView.prototype = {
		init : function() {
			this.activate();
		},
		activate : function() {
			var i, l;
			if ($('#js-accordionBlockSort').length > 0) {
				$('#js-accordionBlockSort').dtaccordion({
					selectedClass : 'open'
				});
				this.sortWrapper = $.data($('#js-accordionBlockSort').get(0), 'accordion');
			}
			//
			$('.js-accordionBlockA').dtaccordion({
				selectedClass : 'open'
			});
			for ( i = 0, l = $('.js-accordionBlockA').length; i < l; i++) {
				this.sortAddressWrapper.push($.data($('.js-accordionBlockA').eq(i).get(0), 'accordion'));
			}
			//
			$('.js-subAccordionBlock').dtaccordion({
				selectedClass : 'open'
			});
			for ( i = 0, l = $('.js-subAccordionBlock').length; i < l; i++) {
				this.sortSubOptWrapper.push($.data($('.js-subAccordionBlock').eq(i).get(0), 'accordion'));
			}
			//
			if ($('#js-indexTab01').length > 0) {
				$('#js-indexTab01').dttab({
					selectedClass : 'active'
				});
				this.sortAddressTabWrapper = $.data($('#js-indexTab01').get(0), 'tab');
			}
			//
			//
			this.resizeCloser();
			this.decision();
			this.changeEventByWindowResize();
		},
		decision : function() {
			var owner = this;
			$('a[role="decision"], input[role="decision"]').bind('click.o', function(e) {
				var w = window.innerWidth, i, l;
				if (w < 768) {
					if (owner.sortWrapper !== undefined) {
						owner.sortWrapper.openPanel(0);
					}
					for ( i = 0, l = owner.sortSubOptWrapper.length; i < l; i++) {
						owner.sortSubOptWrapper[i].closeAllPanel();
					}
				} else if (w >= 768 && w < 1024) {
					if (owner.sortWrapper !== undefined) {
						owner.sortWrapper.closePanel(0);
					}
				} else {
					if (owner.sortWrapper !== undefined) {
						owner.sortWrapper.closePanel(0);
					}
				}
				$('html, body').animate({
					scrollTop : 0
				}, 400, 'swing');
				e.preventDefault();
				return false;
			});

		},
		resizeCloser : function() {
			var owner = this;
			$(window).resize(function() {
				if (owner.w != $(window).width()) {
					owner.debouncer(owner.changeEventByWindowResize, 'resizeTimer', 100, owner);
					owner.w = $(window).width()
				}

			});
		},
		changeEventByWindowResize : function() {
			var owner = this, w = window.innerWidth, m = owner.opts.m, i, l;
			if (w < 768) {
				if (m !== 'sp') {
					if (this.sortWrapper !== undefined) {
						this.sortWrapper.pause();
						this.sortWrapper.openPanel(0);
					}
					//
					for ( i = 0, l = this.sortAddressWrapper.length; i < l; i++) {
						this.sortAddressWrapper[i].restart();
						this.sortAddressWrapper[i].closeAllPanel();
					}
					//
					for ( i = 0, l = this.sortSubOptWrapper.length; i < l; i++) {
						this.sortSubOptWrapper[i].restart();
						this.sortSubOptWrapper[i].closeAllPanel();
					}
					//
					if (this.sortAddressTabWrapper !== undefined) {
						this.sortAddressTabWrapper.restart();
					}
					owner.opts.m = 'sp';
				}
			} else if (w >= 768 && w < 1024) {
				if (m !== 'tb') {
					if (this.sortWrapper !== undefined) {
						this.sortWrapper.restart();
						this.sortWrapper.openPanel(0);
					}
					//
					for ( i = 0, l = this.sortAddressWrapper.length; i < l; i++) {
						this.sortAddressWrapper[i].pause();
						this.sortAddressWrapper[i].openAllPanel();
					}
					//
					for ( i = 0, l = this.sortSubOptWrapper.length; i < l; i++) {
						this.sortSubOptWrapper[i].pause();
						this.sortSubOptWrapper[i].openAllPanel();
					}
					//
					if (this.sortAddressTabWrapper !== undefined) {
						this.sortAddressTabWrapper.restart();
					}
					owner.opts.m = 'tb';
				}
			} else {
				if (m !== 'pc') {
					if (this.sortWrapper !== undefined) {
						this.sortWrapper.restart();
						this.sortWrapper.openPanel(0);
					}
					//
					for ( i = 0, l = this.sortAddressWrapper.length; i < l; i++) {
						this.sortAddressWrapper[i].pause();
						this.sortAddressWrapper[i].openAllPanel();
					}
					//
					for ( i = 0, l = this.sortSubOptWrapper.length; i < l; i++) {
						this.sortSubOptWrapper[i].pause();
						this.sortSubOptWrapper[i].openAllPanel();
					}
					//
					if (this.sortAddressTabWrapper != undefined) {
						this.sortAddressTabWrapper.restart();
					}
					owner.opts.m = 'pc';
				}
			}
		},
		debouncer : function(func, timer, timeout, scope) {
			timeout = timeout || 200;
			var scope = typeof scope === 'undefined' ? this : scope, args = arguments;
			if ( typeof scope[timer] !== 'number') {
				clearTimeout(scope[timer]);
				scope[timer] = setTimeout(function() {
					clearTimeout(scope[timer]);
					func.apply(scope, Array.prototype.slice.call(args));
					scope[timer] = undefined;
				}, timeout);
			}
		}
	};
	function selectAll() {
		$('a[role=selectall]').bind('click.o', function() {
			if (!$(this).hasClass('addmode')) {
				$('ul[role=selectalltarget]').eq(parseInt($(this).attr('data-index'), 10)).find('input').each(function() {
					$(this).attr('checked', true);
				});
				$('ul[role=selectalltarget]').eq(parseInt($(this).attr('data-index'), 10)).find('label').each(function() {
					if (!$(this).hasClass('checkboxON')) {
						$(this).addClass('checkboxON');
					}
				});
				$(this).addClass('addmode').text('すべてのチェックをはずす');
			} else {
				$('ul[role=selectalltarget]').eq(parseInt($(this).attr('data-index'), 10)).find('input').each(function() {
					$(this).removeAttr('checked');
				});
				$('ul[role=selectalltarget]').eq(parseInt($(this).attr('data-index'), 10)).find('label').each(function() {
					if ($(this).hasClass('checkboxON')) {
						$(this).removeClass('checkboxON');
					}
				});
				$(this).removeClass('addmode').text('すべて選択する');
			}
		});
	}

	$(function() {
		window.nrrw = new NarrowSearchOptionView($('#wrap'), {});
		selectAll();
	});
})(jQuery);
