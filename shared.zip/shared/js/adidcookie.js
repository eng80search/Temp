/*====================================================================================================
//////////////////////////////////////////////////////////////////////////////////////////////////////

 created:2009/12/09

 adidの値をcookieに保存するjavascript。
   adid=GETリクエストのadid値
   path=/
   expires=(new Date).getTime()+(30*1000*60*60*24) ※30日
//////////////////////////////////////////////////////////////////////////////////////////////////////
====================================================================================================*/

adidcookie = {
  init:function() {
    var qsParm = new Array();
    var query = window.location.search.substring(1);
    var parms = query.split('&');
    var adid = '';
    var exist = false;
    for (var i = 0; i < parms.length; i++) {
      var pos = parms[i].indexOf('=');
      if (pos > 0) {
        var key = parms[i].substring(0, pos);
        var val = parms[i].substring(pos + 1);
        qsParm[key] = val;
        if (key.toUpperCase() == "ADID") {
          adid = val;
          exist = true;
          break;
        }
      }
    }

    if (exist == true) {
      var d = new Date((new Date).getTime() + (30 * 1000 * 60 * 60 * 24));
      var expire = d.toGMTString();
      document.cookie = "cookieADID=" + adid + "; path=/; expires=" + expire + ";";
    }
  }
}
adidcookie.init();
//window.onload=setCookieAdid;
