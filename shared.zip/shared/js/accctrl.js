;(function($) {
	function AccordionCntlr(ele, options) {
		this.defaults = {
			root : $(ele),
			loaded : [],
			urls : []
		};

		/*
		 *
		 * Note!
		 * this script needs jquery.dtaccordion.js
		 * and buid for
		 * /product/trueye/
		 *
		 *
		 */
		this.accset = [];
		this.w = undefined;
		/*
		 *
		 */
		this.opts = $.extend(this.defaults, options);
		this.init();
	};
	AccordionCntlr.prototype = {
		init : function() {
			this.activate();
		},
		activate : function() {
			var t = this, i, l;
			$('#js-accordionBlockA,#js-accordionBlockB').dtaccordion({
				selectedClass : 'open'
			}).each(function() {
				t.accset.push($.data($(this).get(0), 'accordion'));
			})

			this.resizeCloser();
			this.changeEventByWindowResize();
		},
		resizeCloser : function() {
			var owner = this;
			$(window).resize(function() {
				if (owner.w != $(window).width()) {
					owner.debouncer(owner.changeEventByWindowResize, 'resizeTimer', 300, owner);

					owner.w = $(window).width()
				}

			});
		},
		changeEventByWindowResize : function() {
			var owner = this, w = $(window).width(), i, l;
			if (w < 767) {
				for ( i = 0, l = this.accset.length; i < l; i++) {
					this.accset[i].restart();
					this.accset[i].closeAllPanel();
				}
			} else if (w >= 768 && w < 1024) {
				for ( i = 0, l = this.accset.length; i < l; i++) {
					this.accset[i].pause();
					this.accset[i].openAllPanel();
				}
			} else {
				for ( i = 0, l = this.accset.length; i < l; i++) {
					this.accset[i].pause();
					this.accset[i].openAllPanel();
				}
			}
		},
		debouncer : function(func, timer, timeout, scope) {
			timeout = timeout || 200;
			var scope = typeof scope === 'undefined' ? this : scope, args = arguments;
			if ( typeof scope[timer] != 'number') {
				clearTimeout(scope[timer]);
				scope[timer] = setTimeout(function() {
					clearTimeout(scope[timer]);
					func.apply(scope, Array.prototype.slice.call(args));
					scope[timer] = undefined;
				}, timeout);
			}
		},
	};
	$(function() {
		window.accctrl = new AccordionCntlr($('#wrap'), {});
	})
})(jQuery);
