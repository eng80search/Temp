jQuery(function ($) {

var ngUa = navigator.userAgent;
var ngUaSp = false;

if ( ngUa.indexOf('iPad') != -1 || ( ngUa.indexOf('Android') != -1 && ngUa.indexOf('Mobile') == -1 ) ) ngUaTb = true;
if ( ngUa.indexOf('iPhone') != -1 || ngUa.indexOf('iPod') != -1 || ngUa.indexOf('Android') != -1 ) ngUaSp = true;

//SPのみ
if( ngUaSp === true ){
	//バナーエリア
	$("#bannerArea01").html(
		'<div class="indexBnrBoxA01">'+
		'<ul>'+
		'<li><a href="/goeyedoctor/"><img src="/acuvue-top-img/index_bnr_a_001_sp.png" alt="痛い目に、あう前に。定期検査を受けましょう。眼科へ行こう！" width="600" height="100" class="imgW100"></a></li>'+
		'<li><a href="/begin/"><img src="/acuvue-top-img/index_bnr_a_002_pc.png" alt="はじめてのコンタクトレンズ" width="210" height="60" class="imgW100"></a></li>'+
		'<li><a href="/support/health/"><img src="/acuvue-top-img/index_bnr_a_003_pc.png" alt="瞳の健康のために" width="210" height="60" class="imgW100"></a></li>'+
		'</ul>'+
		'<div class="indexBnrSP"><a href="/app/"><img src="/acuvue-top-img/index_bnr_a_004_sp.png" alt="スマートフォン用 アプリのご紹介" width="599" height="98" class="imgW100"></a></div>'+
		'<!--/indexBnrBoxA01--></div>'+
		'<div class="indexBnrBoxA02">'+
		'<ul>'+
		'<li><a href="/event/"><img src="/acuvue-top-img/index_bnr_b_001_pc.png" alt="キャンペーン情報" width="210" height="60" class="imgW100"></a></li>'+
		'<li><a href="/event/cm/"><img src="/acuvue-top-img/index_bnr_b_002_pc.png" alt="CM情報" width="210" height="60" class="imgW100"></a></li>'+
		'</ul>'+
		'<ul>'+
		'<li><a href="/delivery/"><img src="/acuvue-top-img/index_bnr_b_003_pc.png" alt="アキュビュー デリバリー サービス" width="210" height="60" class="imgW100"></a></li>'+
		'<li><a href="/kauhi/"><img src="/acuvue-top-img/index_bnr_b_004_pc.png" alt="買う日 捨てる日 メール" width="210" height="60" class="imgW100"></a></li>'+
		'</ul>'+
		'</div>');
} else {
	//ログインエリア
	$("#loginArea").html('<iframe src="https://acuvue.jnj.co.jp/myacuvue/loginArea.aspx" frameborder="0" class="login"></iframe>');
	//装用期間や、機能から探す
	$(".indexBoxA01 > .indexBoxInr").html(
		'<h2><img src="/acuvue-top-img/index_txt_001.png" alt="装用期間や、機能から探す" width="382" height="53"></h2>'+
		'<ul>'+
		'<li><a href="/product/?scid=od"><img src="/acuvue-top-img/index_img_001a.png" alt="1日使い捨て" width="200" height="118" class="imgW100"></a></li>'+
		'<li><a href="/product/?scid=tw"><img src="/acuvue-top-img/index_img_001b.png" alt="2週間交換" width="200" height="118" class="imgW100"></a></li>'+
		'<li><a href="/product/acuvue_define/"><img src="/acuvue-top-img/index_img_001c.png" alt="アキュビュー&reg; ディファイン&reg;" width="200" height="118" class="imgW100"></a></li>'+
		'<li><a href="/product/acuvue_astig/"><img src="/acuvue-top-img/index_img_001d.png" alt="アキュビュー&reg; 乱視用" width="200" height="118" class="imgW100"></a></li>'+
		'</ul>');
	//バナーエリア
	$("#bannerArea01").html(
		'<div class="indexBnrBoxA01">'+
		'<ul>'+
		'<li><a href="/goeyedoctor/"><img src="/acuvue-top-img/index_bnr_a_001_pc.png" alt="痛い目に、あう前に。定期検査を受けましょう。眼科へ行こう！" width="210" height="150" class="onlyPC"><img src="/acuvue-top-img/index_bnr_a_001_tb.png" alt="痛い目に、あう前に。定期検査を受けましょう。眼科へ行こう！" width="351" height="90" class="onlyTB"><img src="/acuvue-top-img/index_bnr_a_001_sp.png" alt="痛い目に、あう前に。定期検査を受けましょう。眼科へ行こう！" width="600" height="100" class="onlySP imgW100"></a></li>'+
		'<li><a href="/begin/"><img src="/acuvue-top-img/index_bnr_a_002_pc.png" alt="はじめてのコンタクトレンズ" width="210" height="60" class="onlyPC"><img src="/acuvue-top-img/index_bnr_a_002_tb.png" alt="はじめてのコンタクトレンズ" width="168" height="90" class="onlyTB"><img src="/acuvue-top-img/index_bnr_a_002_pc.png" alt="はじめてのコンタクトレンズ" width="210" height="60" class="onlySP imgW100"></a></li>'+
		'<li><a href="/support/health/"><img src="/acuvue-top-img/index_bnr_a_003_pc.png" alt="瞳の健康のために" width="210" height="60" class="onlyPC"><img src="/acuvue-top-img/index_bnr_a_003_tb.png" alt="瞳の健康のために" width="168" height="90" class="onlyTB"><img src="/acuvue-top-img/index_bnr_a_003_pc.png" alt="瞳の健康のために" width="210" height="60" class="onlySP imgW100"></a></li>'+
		'</ul>'+
		'<div class="indexBnrSP"><a href="/app/"><img src="/acuvue-top-img/index_bnr_a_004_sp.png" alt="スマートフォン用 アプリのご紹介" width="599" height="98" class="imgW100"></a></div>'+
		'<!--/indexBnrBoxA01--></div>'+
		'<div class="indexBnrBoxA02">'+
		'<ul>'+
		'<li><a href="/event/"><img src="/acuvue-top-img/index_bnr_b_001_pc.png" alt="キャンペーン情報" width="210" height="60" class="noTB imgW100"><img src="/acuvue-top-img/index_bnr_b_001_tb.png" alt="キャンペーン情報" width="168" height="90" class="onlyTB"></a></li>'+
		'<li><a href="/event/cm/"><img src="/acuvue-top-img/index_bnr_b_002_pc.png" alt="CM情報" width="210" height="60" class="noTB imgW100"><img src="/acuvue-top-img/index_bnr_b_002_tb.png" alt="CM情報" width="168" height="90" class="onlyTB"></a></li>'+
		'</ul>'+
		'<ul>'+
		'<li><a href="/delivery/"><img src="/acuvue-top-img/index_bnr_b_003_pc.png" alt="アキュビュー デリバリー サービス" width="210" height="60" class="noTB imgW100"><img src="/acuvue-top-img/index_bnr_b_003_tb.png" alt="アキュビュー デリバリー サービス" width="168" height="90" class="onlyTB"></a></li>'+
		'<li><a href="/kauhi/"><img src="/acuvue-top-img/index_bnr_b_004_pc.png" alt="買う日 捨てる日 メール" width="210" height="60" class="noTB imgW100"><img src="/acuvue-top-img/index_bnr_b_004_tb.png" alt="買う日 捨てる日 メール" width="168" height="90" class="onlyTB"></a></li>'+
		'</ul>'+
		'</div>');
}
});