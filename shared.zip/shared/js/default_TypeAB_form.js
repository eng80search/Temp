/* ######################################################################################

body.includeTypeA,Bでformがある場合
───────────────────────────────────────────

	■index
	1. base.js
	2. jquery.dtsubnav.js
	3. jquery.animate-enhanced.min.js
	4. jquery.dttab.js
	5. checkbox.js
	6. jquery.customSelect.js

###################################################################################### */

(function() {
	/*--------------------------------------------
	 インクルードするJS設定
	 --------------------------------------------*/
	var head_include = [], include = {}, jsdefaultpath = '/';
	head_include.push('shared/js/base.js', '', '');
	head_include.push('shared/js/jquery.dtsubnav.js', '', '');
	head_include.push('shared/js/jquery.animate-enhanced.min.js', '', '');
	head_include.push('shared/js/jquery.dttab.js', '', '');
	head_include.push('shared/js/jquery.customSelect.js', '', '');

	/*--------------------------------------------
	HTML　イベント機能
	--------------------------------------------*/
	//HTMLが読み込み完了時に発生するイベント

	window.onload = function() {
		include.setloadFun();
	};
	//HTMLがアンロード時（ページを抜けるとき?）に発生するイベント
	window.onunload = function() {
		include.setonloadFun();
	};

	include = {
		_init : function() {
			var roop = head_include.length / 3, name, loadfun, onloadfun, jsname = "", i;
			this.jsloadfun = '';
			this.jsonunloadfun = '';
			for ( i = 0; i <= roop - 1; i++) {
				name = i * 3;
				loadfun = i * 3 + 1;
				onloadfun = i * 3 + 2;
				if (head_include[name] != '') {
					jsname = head_include[name];
					include.setJS(jsname);
				};
				if (head_include[loadfun] != '') {
					this.jsloadfun += head_include[loadfun];
				};
				if (head_include[onloadfun] != '') {
					this.jsonunloadfun += head_include[onloadfun];
				};
			};
		},
		setJS : function(astrFile) {
			document.write("<sc" + "ript type=\'text/javascript\' src=\'" + jsdefaultpath + astrFile + "\'></sc" + "ript>");
		},
		setloadFun : function() {
			(new Function(this.jsloadfun))();
		},
		setonloadFun : function() {
			(new Function(this.jsonunloadfun))();
		}
	};
	include._init();

})()


$(document).ready(function(){
	$('.ctSelect').customSelect({customClass:'customSelect'});
});

