(function() {
	/*--------------------------------------------
	 インクルードするJS設定
	 --------------------------------------------*/
	var ar_include = [], include = {}, jsdefaultpath = '/';
	ar_include.push('shared/js/adidcookie.js', '', '');
	ar_include.push('shared/js/gtm.js', '', '');
	//ar_include.push('shared/js/uni.js', '', '');
	ar_include.push('shared/js/yjtag.js', '', '');

	/*-------------------------------------------
	10/28までに公開するページについては下記を記載すること
	ar_include.push('shared/js/ga.js', '', '');
	-------------------------------------------*/

	/*--------------------------------------------
	HTML　イベント機能
	--------------------------------------------*/
	//HTMLが読み込み完了時に発生するイベント

	window.onload = function() {
		include.setloadFun();
	};
	//HTMLがアンロード時（ページを抜けるとき?）に発生するイベント
	window.onunload = function() {
		include.setonloadFun();
	};

	include = {
		_init : function() {
			var roop = ar_include.length / 3, name, loadfun, onloadfun, jsname = "", i;
			this.jsloadfun = '';
			this.jsonunloadfun = '';
			for ( i = 0; i <= roop - 1; i++) {
				name = i * 3;
				loadfun = i * 3 + 1;
				onloadfun = i * 3 + 2;
				if (ar_include[name] != '') {
					jsname = ar_include[name];
					include.setJS(jsname);
				};
				if (ar_include[loadfun] != '') {
					this.jsloadfun += ar_include[loadfun];
				};
				if (ar_include[onloadfun] != '') {
					this.jsonunloadfun += ar_include[onloadfun];
				};
			};
		},
		setJS : function(astrFile) {
			document.write("<sc" + "ript type=\'text/javascript\' src=\'" + jsdefaultpath + astrFile + "\'></sc" + "ript>");
		},
		setloadFun : function() {
			(new Function(this.jsloadfun))();
		},
		setonloadFun : function() {
			(new Function(this.jsonunloadfun))();
		}
	};
	include._init();
})()