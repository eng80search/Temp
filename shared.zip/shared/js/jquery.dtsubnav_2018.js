;(function($) {
	function LoadHeaderAndFooter(ele, options) {
		this.defaults = {
			root : $(ele),
			loaded : {
				'hdr' : undefined,
				'ftr' : undefined,
				'spm' : undefined
			},
			urls : {}
		};
		this.opts = $.extend(this.defaults, options);
		this.cnt = 0;
		this.init();
	};
	LoadHeaderAndFooter.prototype = {
		init : function() {
			// アキュビュー静的 基本セット
			if ($('body').hasClass('includeTypeA')) {
				this.opts.urls = {
					'hdr' : '/shared/include/2018/headertype01.htm',
					'ftr' : '/shared/include/2018/footertype01.htm',
					'spm' : undefined
				};
				// アキュビュー静的 【ヘッダー】ロゴのみ【フッター】リンク_blank
			} else if ($('body').hasClass('includeTypeA2')) {
				this.opts.urls = {
					'hdr' : '/shared/include/2018/headertype02.htm',
					'ftr' : '/shared/include/2018/footertype02Blank.htm',
					'spm' : undefined
				};
				// アキュビュー動的 【ヘッダー】ロゴのみ【フッター】リンク_blank（SNSなし）
			} else if ($('body').hasClass('includeTypeB')) {
				this.opts.urls = {
					'hdr' : '/shared/include/2018/headertype02.htm',
					'ftr' : '/shared/include/2018/footertype03Blank.htm',
					'spm' : undefined
				};
				// Myアキュビュー静的
			} else if ($('body').hasClass('includeTypeM01')) {
				this.opts.urls = {
					'hdr' : '/shared/include/2018/headertypeM01.htm',
					'ftr' : '/shared/include/2018/footertypeM01.htm',
					'spm' : '/shared/include/2018/spmenuM01.htm'
				};
				// Acuproフォーム
			} else if ($('body').hasClass('includeTypeAPRO')) {
				this.opts.urls = {
					'hdr' : '/shared/include/2018/headertypeA01.htm',
					'ftr' : '/shared/include/2018/footertypeA01.htm',
					'spm' : undefined
				};

			}
			this.loadCtrlr();
		},
		loadCtrlr : function() {
			var key;
			for (key in this.opts.loaded) {
				this.ajaxLoad(this.opts.urls[key], key)
			}
			//this.putHtml()
			//}
		},
		putHtml : function(key) {
			var root = this.opts.root, o = this.opts;
			if (root.find('#header').length <= 0 && key == 'hdr') {
				root.children().eq(0).before(o.loaded[key]);
			} else if (root.find('#header').length > 0 && key == 'hdr') {
				//$('.js-navProduct').find('a').attr('href', 'javascript:;');
			}
			if (root.find('#footer').length <= 0 && key == 'ftr') {
				root.children().eq(root.children().length - 1).after(o.loaded[key]);
			};
			if (root.find('#footer').length > 0 && root.find('#footer02').length <= 0 && key == 'ftr') {
				var f2 = $($(o.loaded[key]).remove('#footer'));
				root.children().eq(root.children().length - 1).after(f2);
			};
			if (root.find('.spMenuA01').length <= 0 && root.find('.spMenuA02').length <= 0 && key == 'spm') {
				root.children().eq(root.children().length - 1).after(o.loaded[key]);
			};
			this.cnt++
			if (this.cnt == 3) {
				this.addUpdate();
				this.addCurrent();
				this.getUTCDateByServer();
				this.addPositionFixHeader();
				$('#wrap').dtsubnav();
//				$('#nav').dtDropDwonMenu();
			};
			$('body').delegate('a[href^=#]:not(.popup-modal)', 'click.o', function() {
				var speed = 400, href = $(this).attr('href'), target = $(href == '#' || href == '' ? 'html' : href), fh = 0, fb = 0, h = 0;

				if (target.closest('[role="accordion-btn"]').length > 0) {
					$.data(target.closest('[role="accordion-btn"]').parent().get(0), 'accordion').openPanel(~~(target.closest('[role="accordion-btn"]').attr('data-index')));
				}
				if (target.closest('[role="accordion-panel"]').length > 0) {
					$.data(target.closest('[role="accordion-panel"]').parent().get(0), 'accordion').openPanel(~~(target.closest('[role="accordion-panel"]').attr('data-index')));
				}

				if ($('#header').length > 0 && $('#header').css('position') == 'fixed') {
					fh = $('#header').height();
				}

				if ($('#fixedBox').length > 0 && $('#fixedBox').css('position') == 'fixed') {
					fb = $('#fixedBox').height();
				}
				h = fh > fb ? fh : fb;
				if (target.length) {
					var position = target.offset().top - h;
					$('html, body').animate({
						scrollTop : position
					}, speed, 'swing');
				}
				return false;
			});

			if ( typeof location.href.split("#")[1] != 'undefined') {
				var target = $('#' + location.href.split("#")[1]), fh = 0, fb = 0, h = 0;
				if (target.length) {
					if ($('#header').length > 0 && $('#header').css('position') == 'fixed') {
						fh = $('#header').height();
					}

					if ($('#fixedBox').length > 0 && $('#fixedBox').css('position') == 'fixed') {
						fb = $('#fixedBox').height();
					}
					h = fh > fb ? fh : fb;

					var position = target.offset().top - h;
					if (target.length) {
						$('html,body').animate({
							scrollTop : position
						}, 0, 'swing');
						return false;
					}
				}
			}
		},
		addUpdate : function() {
			if ($('meta[name=date]').length > 0 && $('.lastUpdated').length > 0) {
				var date, month, year, ref, m;
				m = ($('meta[name=date]').attr('content')).match(/(\d+)\D+(\d+)\D+(\d+)/);
				if (m != null) {
					ref = m.slice(1, 4);
					year = ~~(ref[0]);
					month = ~~(ref[1]);
					date = ~~(ref[2]);
					$('.lastUpdated').text('最終更新日：' + year + '年' + month + '月' + date + '日');
				}
			}
		},
		addCurrent : function() {
			if (location.pathname != "/") {
				$('#nav a[href^="/' + location.pathname.split("/")[1] + '"]').closest('li').addClass('active');
			}
		},
		addCopyrightTerm : function(yy) {
			var y = yy, root = this.opts.root, o = this.opts;
			if (yy != null) {
				if (root.find('#footer02').length > 0 && $('.copyrightTerm').length > 0 && parseInt(yy.getFullYear(), 10) > 2000) {
					$('.copyrightTerm').text('1997-' + yy.getFullYear());
				}
			}
		},
		addPositionFixHeader : function() {
			$(window).bind('scroll.o', function() {
				var s = $(document).scrollTop() || $(window).scrollTop();
				if (s > 640) {
					$('.goTop').stop().animate({
						'opacity' : 1
					}, {
						'duration' : 450
					});
				} else {
					$('.goTop').stop().animate({
						'opacity' : 0
					}, {
						'duration' : 450
					});
				}
			});
			$('.goTop').css({
				'opacity' : '0'
			});
			var s = $(document).scrollTop() || $(window).scrollTop()
			if (s > 640) {
				$('.goTop').stop().animate({
					'opacity' : 1
				}, {
					'duration' : 450
				});
			} else {
				$('.goTop').stop().animate({
					'opacity' : 0
				}, {
					'duration' : 450
				});
			}
		},
		addGotoTop : function() {
			return true;
		},
		ajaxLoad : function(u, key) {
			var t = this;
			if ( typeof u !== 'undefined') {
				$.ajax({
					url : u,
					dataType : 'html',
					success : function(html) {
						t.opts.loaded[key] = html;
						t.putHtml(key);
					}
				});
			} else {
				t.opts.loaded[key] = '';
				t.putHtml(key);
			}
		},
		getUTCDateByServer : function() {
			/*
 　			* MODE:true  ->サーバータイム
  　		* MODE:false ->西暦固定入力
			*/
			var MODE = true;
			/* var MODE = false,yyyy = '2020';*/
			if(MODE){
				var date = null, t = this, oHead = $.ajax({
					'type' : 'HEAD',
					'url' : '/'
				}).success(function() {
					date = new Date(oHead.getResponseHeader('Date'));
					t.addCopyrightTerm(date);
				}).error(function(){
					$('.copyrightTerm').text('1997-' + yyyy);
				});
			} else {
				this.setConstDate(yyyy)
			}
		},
		setConstDate : function(yyyy){
			$('.copyrightTerm').text('1997-' + yyyy);
		}
	};
	$(function() {
		window.lhaf = new LoadHeaderAndFooter($('#wrap'), {});
	});
})(jQuery);

;(function($) {
	$.dtsubnav = function(ele, options) {
		this.defaults = {
			root : $(ele),
			is : $(ele).attr('id'),
			cacheNav : undefined,
			cacheSer : undefined
		};
		this.resizeTimer = undefined;
		this.opts = $.extend(this.defaults, options);
		this.init()
	};
	$.extend($.dtsubnav.prototype, {
		init : function() {
			var owner = this, search = '', navStr = '';
			/*
			*
			*/
			//search += '<div class="spMenuBG02"></div>';
			search = $('.spMenuA02,.spMenuBG02');
			search.css({
				'height' : 0,
				'overflow' : 'hidden'
			})
			//search.remove()
			/*
			*
			*/
			//navStr += '<div class="spMenuBG" style="height: 768px"></div>';
			navStr = $('.spMenuA01,.spMenuBG');
			navStr.remove()

			/*
			 *
			 */
			owner.search = search;
			owner.navStr = navStr;
			owner.resizeCloser();
			owner.setBtnEvent();
		},
		resizeCloser : function() {
			var owner = this;
			$(window).resize(function() {
				owner.debouncer(owner.autoClose, 'resizeTimer', 100, owner);
			})
		},
		autoClose : function() {
			if ($(window).width() >= 768) {
				if ($('a[role="js-search-close"]').length > 0) {
					$('a[role="js-search-close"]').trigger('click');
				}
				if ($('a[role="js-nav-close"]').length > 0) {
					$('a[role="js-nav-close"]').trigger('click');
				}
			}
		},
		debouncer : function(func, timer, timeout, scope) {
			timeout = timeout || 200;
			var scope = typeof scope === 'undefined' ? this : scope, args = arguments;
			if ( typeof scope[timer] != 'number') {
				clearTimeout(scope[timer]);
				scope[timer] = setTimeout(function() {
					clearTimeout(scope[timer]);
					func.apply(scope, Array.prototype.slice.call(args));
					scope[timer] = undefined;
				}, timeout);
			}
		},
		setDefaultSelected : function() {
			var owner = this, root = owner.opts.root;
			root.children('ul').children('li[role*="tab-btn"]').each(function(i) {
				if (i == owner.opts.selected) {
					$(this).addClass(owner.opts.selectedClass);
				}
				$(this).attr('data-index', i);
			});
			root.children('div[role*="tab-panel"]').each(function(i) {
				if (i !== owner.opts.selected) {
					$(this).css({
						'display' : 'none'
					});
					owner.opts.cache = owner.opts.selected;
				}
				$(this).attr('data-index', i);
			});
		},
		setBtnEvent : function() {
			var owner = this, root = owner.opts.root;
			$('#js-menu').bind('click.o', function() {
				var h = (window.innerWidth > window.innerHeight) ? window.innerWidth : window.innerHeight, stid;
				h = h > 768 ? h : 768;
				stid = setTimeout(function() {
					$('#js-subNavTab').dtsubnavtab({
						selectedClass : 'active'
					});
					root.css({
						'overflow' : 'hidden',
						'display' : 'block',
						'height' : h + 'px'
					});
					$('.spMenuBG').css({
						'display' : 'block',
						'height' : h + 'px'
					});
					$('.spMenuA01').css({
						'display' : 'block',
						'height' : h + 'px',
						'-webkit-transform' : 'translateZ(0)'
					});

				}, 1);
				if ($('.spMenuBG').length <= 0 && $('.spMenuA01').length <= 0) {
					owner.opts.cacheNav = root.children().eq(0).before(owner.navStr);
				}
				//if ($('body').attr('id') === 'top') {
				$('.spMenuBG,.spMenuA01').css({
					'display' : 'block'
				});
				//}
				return false;
			})
			$(document).delegate('#js-search', 'click.o', function() {
				//owner.opts.cacheSer = root.children().eq(0).before(owner.search)
				//if ($('body').attr('id') === 'top') {
				$('.spMenuBG02,.spMenuA02').css({
					'display' : 'block'
				})
				$('.spMenuA02').css({
					'height' : 'auto',
					'overflow' : 'visible'
				})
				$('.spMenuBG02').css({
					'height' : '124px'
				})
				//}
				$('#contentsBody').css({
					'margin-top' : '54px'
				});
				return false;
			})
			$(document).delegate('a[role="js-search-close"],a[role="js-nav-close"]', 'click.o', function() {
				root.css({
					'overflow' : '',
					'display' : '',
					'height' : ''
				});
				if ($('.spMenuA01').length > 0)
					$('.spMenuA01').remove();
				if ($('.spMenuA02').length > 0)
					//$('.spMenuA02').remove();
					$('.spMenuA02').css({
						'height' : '0',
						'overflow' : 'hidden'
					})
				if ($('.spMenuBG').length > 0)
					$('.spMenuBG').remove();
				if ($('.spMenuBG02').length > 0) {
					$('.spMenuBG02').css({
						'height' : '0',
						'overflow' : 'hidden'
					})

				}
				//root.removeAttr('style');
				$('#contentsBody').css({
					'margin-top' : ''
				})
				return false;
			})
		}
	});
	$.fn.dtsubnav = function(options) {
		return this.each(function() {
			new $.dtsubnav(this, options);
		});
	};

})(jQuery);


