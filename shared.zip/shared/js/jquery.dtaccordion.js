/**
 * @fileOverview アコーディオンUI制御 -dtaccordion
 *
 * @author
 * @version 1.0.0
 */
;(function($) {
	$.dtaccordion = function(ele, options) {
		/**
		 * @property {Object} property Default values
		 * @attribute {Number} a Attribute a description
		 * @attribute {String} b Attribute b description
		 * @attribute {Boolean} Attribute c description
		 */
		this.defaults = {
			root : $(ele),
			selectedClass : '',
			pauseFlg : false,
			deviceAdjust : ''
		};
		this.w = undefined;
		this.m = undefined;
		this.eventAttached = false;
		this.opts = $.extend(this.defaults, options);
		this.init()
	};
	$.extend($.dtaccordion.prototype, {
		init : function() {
			var owner = this;
			owner.setDefaultSelected();
			owner.setBtnEvent();
			if (owner.opts.deviceAdjust.length === 3) {
				owner.resizeCloser();
				owner.changeEventByWindowResize();
			}
		},
		setDefaultSelected : function() {
			var owner = this, root = owner.opts.root, c = owner.opts.selectedClass;
			root.children(':header[role*="accordion-btn"]').each(function(i) {
				if ($(this).hasClass(c)) {
					root.children('div[role*="accordion-panel"]').eq(i).css({
						'display' : 'block'
					});
				} else {
					root.children('div[role*="accordion-panel"]').eq(i).css({
						'display' : 'none'
					});
				}
				$(this).attr('data-index', i);
			});
			root.children('div[role*="accordion-panel"]').each(function(i) {
				$(this).attr('data-index', i);
			});
		},
		setBtnEvent : function() {
			var owner = this, root = owner.opts.root, c = owner.opts.selectedClass;
			if (!owner.eventAttached) {
				owner.eventAttached = true;
				root.children(':header[role*="accordion-btn"]').each(function(i) {
					$(this).children('a:not([role])').bind('click.o', function(e) {
						if (!owner.opts.pauseFlg) {
							if ($(this).parent().hasClass(c)) {
								$(this).parent().removeClass(c);
								var h = root.children('div[role*="accordion-panel"][data-index=' + $(this).parent().attr('data-index') + ']').outerHeight(true);
								root.children('div[role*="accordion-panel"][data-index=' + $(this).parent().attr('data-index') + ']').wrap('<div class="acc-anime-wrap"></div>').parent().css({
									'height' : h + 'px',
									'overflow' : 'hidden'
								});
								var sc = root.children('.acc-anime-wrap').children('div[role*="accordion-panel"][data-index=' + $(this).parent().attr('data-index') + ']');
								root.children('.acc-anime-wrap').children('div[role*="accordion-panel"][data-index=' + $(this).parent().attr('data-index') + ']').removeAttr('style');
								root.children('.acc-anime-wrap').children('div[role*="accordion-panel"][data-index=' + $(this).parent().attr('data-index') + ']').parent().stop().animate({
									'height' : 0
								}, {
									'duration' : 450,
									'easing' : 'easeOutExpo',
									'complete' : function(e) {
										sc.css({
											'display' : 'none'
										})
										$(this).children().unwrap()
									}
								});
							} else {
								$(this).parent().addClass(c);
								root.children('div[role*="accordion-panel"][data-index=' + $(this).parent().attr('data-index') + ']').wrap('<div class="acc-anime-wrap"></div>').parent().css({
									'height' : 0,
									'overflow' : 'hidden'
								});
								root.children('.acc-anime-wrap').children('div[role*="accordion-panel"][data-index=' + $(this).parent().attr('data-index') + ']').removeAttr('style');
								var h = root.children('.acc-anime-wrap').children('div[role*="accordion-panel"][data-index=' + $(this).parent().attr('data-index') + ']').outerHeight(true);
								root.children('.acc-anime-wrap').children('div[role*="accordion-panel"][data-index=' + $(this).parent().attr('data-index') + ']').parent().stop().animate({
									'height' : h + 'px'
								}, {
									'duration' : 800,
									'easing' : 'easeOutExpo',
									'complete' : function(e) {
										$(this).children().unwrap()
									}
								});
							};
						}
						e.preventDefault();
						return false;
					});
					$(this).children('a:not([role])').css({
						'cursor' : 'pointer'
					})
				});
			}
		},
		destroy : function() {
		},
		pause : function() {
			this.opts.pauseFlg = true;
			this.eventAttached = false;
			var owner = this, root = owner.opts.root, c = owner.opts.selectedClass;
			root.children(':header[role*="accordion-btn"]').each(function() {
				$(this).children('a:not([role])').unbind('click');
				$(this).children('a:not([role])').css({
					'cursor' : 'default'
				})
			});
		},
		restart : function() {
			var owner = this, root = owner.opts.root, c = owner.opts.selectedClass;
			owner.opts.pauseFlg = false;
			if (!owner.eventAttached) {
				owner.setBtnEvent();
			}
		},
		closePanel : function(n) {
			var owner = this, root = owner.opts.root, c = owner.opts.selectedClass;
			root.children(':header[role*="accordion-btn"]').eq(n).removeClass(c);
			root.children('div[role*="accordion-panel"]').eq(n).css({
				'display' : 'none'
			});

		},
		openPanel : function(n) {
			var owner = this, root = owner.opts.root, c = owner.opts.selectedClass;
			root.children(':header[role*="accordion-btn"]').eq(n).addClass(c);
			root.children('div[role*="accordion-panel"]').eq(n).css({
				'display' : 'block'
			});
		},
		openPanelAnime : function(n) {
			var owner = this, root = owner.opts.root, c = owner.opts.selectedClass;
			if (!root.children(':header[role*="accordion-btn"]').eq(n).hasClass(c)) {
				root.children(':header[role*="accordion-btn"]').eq(n).children('a:not([role])').trigger('click.o')
			}
		},
		closeAllPanel : function() {
			var owner = this, root = owner.opts.root, c = owner.opts.selectedClass;
			for ( i = 0; i < root.children(':header[role*="accordion-btn"]').length; i++) {
				owner.closePanel(i)
			}
		},
		openAllPanel : function() {
			var owner = this, root = owner.opts.root, c = owner.opts.selectedClass;
			for ( i = 0; i < root.children(':header[role*="accordion-btn"]').length; i++) {
				owner.openPanel(i)
			}
		},
		resizeCloser : function() {
			var owner = this;
			var timer = false;
			$(window).on('resize', function() {
				if (timer !== false) {
					clearTimeout(timer)
				};
				timer = setTimeout(function() {
					if (owner.w != window.innerWidth) {
						owner.debouncer(owner.changeEventByWindowResize, 'resizeTimer', 300, owner);
						owner.w = window.innerWidth
					}
				}, 300);
			});
		},
		changeEventByWindowResize : function() {
			var owner = this, w = window.innerWidth, m = owner.opts.m, r = owner.opts.root, j = owner.opts.deviceAdjust.split(''), i, l;
			if (w < 768) {
				if (m !== 'sp') {
					if (Boolean(~~(j[0]))) {
						owner.restart();
						owner.closeAllPanel();
					} else {
						owner.pause();
						owner.openAllPanel();
					}
					owner.opts.m = 'sp';
				}
			} else if (w >= 768 && w < 1024) {
				if (m !== 'tb') {
					if (Boolean(~~(j[1]))) {
						owner.restart();
						owner.closeAllPanel();
					} else {
						owner.pause();
						owner.openAllPanel();
					}
					owner.opts.m = 'tb';
				}
			} else {
				if (m !== 'pc') {
					if (Boolean(~~(j[2]))) {
						owner.restart();
						owner.closeAllPanel();
					} else {
						owner.pause();
						owner.openAllPanel();
					}
					owner.opts.m = 'pc';
				}
			}
		},
		debouncer : function(func, timer, timeout, scope) {
			timeout = timeout || 200;
			var scope = typeof scope === 'undefined' ? this : scope, args = arguments;
			if ( typeof scope[timer] != 'number') {
				clearTimeout(scope[timer]);
				scope[timer] = setTimeout(function() {
					clearTimeout(scope[timer]);
					func.apply(scope, Array.prototype.slice.call(args));
					scope[timer] = undefined;
				}, timeout);
			}
		}
	});
	$.fn.dtaccordion = function(options) {
		return this.each(function() {
			var obj = new $.dtaccordion(this, options);
			$.data(this, 'accordion', obj);
		});
	};
	/*
	* jQuery Easing v1.3 - http://gsgd.co.uk/sandbox/jquery/easing/
	*
	* Uses the built in easing capabilities added In jQuery 1.1
	* to offer multiple easing options
	*
	* TERMS OF USE - jQuery Easing
	*
	* Open source under the BSD License.
	*
	* Copyright © 2008 George McGinley Smith
	* All rights reserved.
	*
	* Redistribution and use in source and binary forms, with or without modification,
	* are permitted provided that the following conditions are met:
	*
	* Redistributions of source code must retain the above copyright notice, this list of
	* conditions and the following disclaimer.
	* Redistributions in binary form must reproduce the above copyright notice, this list
	* of conditions and the following disclaimer in the documentation and/or other materials
	* provided with the distribution.
	*
	* Neither the name of the author nor the names of contributors may be used to endorse
	* or promote products derived from this software without specific prior written permission.
	*
	* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
	* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
	* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
	*  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
	*  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
	*  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
	* AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
	*  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
	* OF THE POSSIBILITY OF SUCH DAMAGE.
	*
	*/

	// t: current time, b: begInnIng value, c: change In value, d: duration
	jQuery.easing['jswing'] = jQuery.easing['swing'];

	jQuery.extend(jQuery.easing, {
		def : 'easeOutQuad',
		easeOutExpo : function(x, t, b, c, d) {
			return (t == d) ? b + c : c * (-Math.pow(2, -10 * t / d) + 1) + b;
		}
	});

	/*
	 *
	 * TERMS OF USE - EASING EQUATIONS
	 *
	 * Open source under the BSD License.
	 *
	 * Copyright © 2001 Robert Penner
	 * All rights reserved.
	 *
	 * Redistribution and use in source and binary forms, with or without modification,
	 * are permitted provided that the following conditions are met:
	 *
	 * Redistributions of source code must retain the above copyright notice, this list of
	 * conditions and the following disclaimer.
	 * Redistributions in binary form must reproduce the above copyright notice, this list
	 * of conditions and the following disclaimer in the documentation and/or other materials
	 * provided with the distribution.
	 *
	 * Neither the name of the author nor the names of contributors may be used to endorse
	 * or promote products derived from this software without specific prior written permission.
	 *
	 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
	 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
	 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
	 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
	 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
	 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
	 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
	 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
	 * OF THE POSSIBILITY OF SUCH DAMAGE.
	 *
	 */
})(jQuery);
