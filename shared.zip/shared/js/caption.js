$(window).bind('load',function(){
	$('.captionImg01').each(function(){
		pw = $(this).prev('img').width() + 'px';
		$(this).parent().css('width',pw);
	});
});
	